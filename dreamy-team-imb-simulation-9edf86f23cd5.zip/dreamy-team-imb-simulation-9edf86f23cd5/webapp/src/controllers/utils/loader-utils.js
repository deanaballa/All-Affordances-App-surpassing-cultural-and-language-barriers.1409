
export function showLoader() {
    $("#loader-container").removeClass('hide');
}

export function hideLoader() {
    $("#loader-container").addClass('hide');
}
